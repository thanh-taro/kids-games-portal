// effects.js — dot particle bursts for hits, deaths, and skill flashes.

import { DOT } from './render.js';

export class Particle {
  constructor(x, y, vx, vy, color, life) {
    this.x = x;
    this.y = y;
    this.vx = vx;
    this.vy = vy;
    this.color = color;
    this.life = life;
    this.maxLife = life;
  }
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.vy += 0.35; // gravity
    this.life--;
  }
  get dead() {
    return this.life <= 0;
  }
}

export class ParticleSystem {
  constructor() {
    this.particles = [];
  }

  // Deterministic-ish burst (no Math.random dependency for reproducibility):
  // spray n dots in a ring pattern with per-index variation.
  burst(x, y, color, n = 16, power = 4) {
    for (let i = 0; i < n; i++) {
      const angle = (Math.PI * 2 * i) / n;
      const spd = power * (0.6 + ((i % 3) * 0.2));
      this.particles.push(
        new Particle(x, y, Math.cos(angle) * spd, Math.sin(angle) * spd - 2, color, 24 + (i % 8))
      );
    }
  }

  update() {
    for (const p of this.particles) p.update();
    this.particles = this.particles.filter((p) => !p.dead);
  }

  draw(ctx) {
    for (const p of this.particles) {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      ctx.fillRect(p.x, p.y, DOT * 1.5, DOT * 1.5);
    }
    ctx.globalAlpha = 1;
  }

  get empty() {
    return this.particles.length === 0;
  }
}
