// stages.js — data-driven stage definitions.
//
// Each stage is a curriculum step (letters -> words -> phrases -> sentences),
// a wave sequence (creeps / elites / boss / stageboss), a princess to rescue,
// and flavor text for the intro/victory scenes.
//
// A wave entry: { type, pool?, skill? }
//   type: 'creep' | 'elite' | 'boss' | 'stageboss'
//   pool: which WORD_POOLS tier to draw the target word from (skills.js)
//   skill: which SKILLS entry the hero uses on that monster

export const STAGES = [
  {
    id: 1,
    name: 'Đồng Cỏ Xanh',        // "Green Meadow"
    princess: 'Công Chúa Hoa',   // "Princess Flower"
    intro: 'Học gõ chữ cái đầu tiên!', // "Learn your first letters!"
    waves: [
      { type: 'creep', pool: 'letters', skill: 'slash' },
      { type: 'creep', pool: 'letters', skill: 'slash' },
      { type: 'creep', pool: 'letters', skill: 'slash' },
      { type: 'creep', pool: 'letters', skill: 'slash' },
      { type: 'stageboss', pool: 'words', skill: 'fireball' },
    ],
  },
  {
    id: 2,
    name: 'Rừng Rậm',            // "Deep Forest"
    princess: 'Công Chúa Suối',  // "Princess Stream"
    intro: 'Ghép chữ thành từ!', // "Combine letters into words!"
    waves: [
      { type: 'creep', pool: 'words', skill: 'slash' },
      { type: 'creep', pool: 'words', skill: 'slash' },
      { type: 'elite', pool: 'words', skill: 'fireball' },
      { type: 'creep', pool: 'words', skill: 'slash' },
      { type: 'boss', pool: 'phrases', skill: 'fireball' },
      { type: 'stageboss', pool: 'phrases', skill: 'meteor' },
    ],
  },
  {
    id: 3,
    name: 'Hang Động Tối',       // "Dark Cave"
    princess: 'Công Chúa Sao',   // "Princess Star"
    intro: 'Gõ cả cụm từ!',      // "Type whole phrases!"
    waves: [
      { type: 'creep', pool: 'words', skill: 'slash' },
      { type: 'elite', pool: 'phrases', skill: 'fireball' },
      { type: 'boss', pool: 'phrases', skill: 'lightning' },
      { type: 'elite', pool: 'phrases', skill: 'fireball' },
      { type: 'stageboss', pool: 'sentences', skill: 'meteor' },
    ],
  },
  {
    id: 4,
    name: 'Lâu Đài Rồng',        // "Dragon Castle"
    princess: 'Công Chúa Ánh Dương', // "Princess Sunlight"
    intro: 'Gõ được cả câu dài!', // "Type full sentences!"
    waves: [
      { type: 'elite', pool: 'phrases', skill: 'fireball' },
      { type: 'boss', pool: 'sentences', skill: 'lightning' },
      { type: 'boss', pool: 'sentences', skill: 'meteor' },
      { type: 'stageboss', pool: 'sentences', skill: 'meteor' },
    ],
  },
];

export function getStage(index) {
  return STAGES[Math.min(index, STAGES.length - 1)];
}

export const TOTAL_STAGES = STAGES.length;
