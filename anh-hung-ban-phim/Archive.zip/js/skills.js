// skills.js — skill definitions and the word pools that trigger them.
//
// Two skill classes:
//   SIMPLE  — basic attack. Short, easy targets (letters / short words).
//             Used against Creep monsters.
//   SPECIAL — ultimate attacks. Longer / harder targets (phrases, tricky
//             diacritics). Needed to damage Boss and Stage Boss monsters.
//
// Each skill defines how its projectile looks and how much it hurts, so the
// game can render distinct effects and apply distinct damage.

export const SKILL_CLASS = {
  SIMPLE: 'simple',
  SPECIAL: 'special',
};

// A "skill" bundles a visual + damage profile. The actual target WORD comes
// from the stage's word pool; skills describe the *effect* of a correct type.
export const SKILLS = {
  // ---- Simple attacks (basic) ----
  slash: {
    id: 'slash',
    cls: SKILL_CLASS.SIMPLE,
    name: 'Chém', // "Slash"
    damage: 25,
    projectile: { color: '#e8c33a', size: 8, speed: 16, count: 1, special: false },
    burst: { color: '#e8c33a', n: 16, power: 4 },
  },

  // ---- Special / ultimate attacks ----
  fireball: {
    id: 'fireball',
    cls: SKILL_CLASS.SPECIAL,
    name: 'Cầu Lửa', // "Fireball"
    damage: 55,
    projectile: { color: '#c0392b', size: 12, speed: 13, count: 3, special: true },
    burst: { color: '#e8622b', n: 30, power: 6 },
    shake: 16,
  },
  lightning: {
    id: 'lightning',
    cls: SKILL_CLASS.SPECIAL,
    name: 'Sấm Sét', // "Lightning"
    damage: 60,
    projectile: { color: '#4ad4d4', size: 10, speed: 22, count: 2, special: true },
    burst: { color: '#7fe8ff', n: 34, power: 7 },
    shake: 18,
  },
  meteor: {
    id: 'meteor',
    cls: SKILL_CLASS.SPECIAL,
    name: 'Thiên Thạch', // "Meteor"
    damage: 75,
    projectile: { color: '#8e44ad', size: 14, speed: 11, count: 4, special: true },
    burst: { color: '#c77dff', n: 42, power: 8 },
    shake: 22,
  },
};

// Word pools by difficulty tier. The game picks a word from the tier that
// matches the monster/skill being used.
export const WORD_POOLS = {
  // Tier 1: single letters, vowels, tones — earliest learners.
  letters: [
    { vi: 'a', telex: 'a' },
    { vi: 'á', telex: 'as' },
    { vi: 'à', telex: 'af' },
    { vi: 'â', telex: 'aa' },
    { vi: 'ă', telex: 'aw' },
    { vi: 'đ', telex: 'dd' },
    { vi: 'ê', telex: 'ee' },
    { vi: 'ô', telex: 'oo' },
    { vi: 'ơ', telex: 'ow' },
    { vi: 'ư', telex: 'uw' },
  ],
  // Tier 2: short everyday words.
  words: [
    { vi: 'mẹ', telex: 'mej' },
    { vi: 'bố', telex: 'boos' },
    { vi: 'cá', telex: 'cas' },
    { vi: 'gà', telex: 'gaf' },
    { vi: 'mèo', telex: 'meof' },
    { vi: 'chó', telex: 'chos' },
    { vi: 'nhà', telex: 'nhaf' },
    { vi: 'cây', telex: 'caay' },
    { vi: 'bé', telex: 'bes' },
    { vi: 'sữa', telex: 'suwac' },
    { vi: 'trứng', telex: 'truwsng' },
    { vi: 'bánh', telex: 'basnh' },
    { vi: 'vịt', telex: 'vitj' },
    { vi: 'ông', telex: 'oong' },
    { vi: 'bà', telex: 'baf' },
    { vi: 'sách', telex: 'sasch' },
  ],
  // Tier 3: two-word phrases — used for SPECIAL skills / bosses.
  phrases: [
    { vi: 'con mèo', telex: 'con meof' },
    { vi: 'quả cam', telex: 'quar cam' },
    { vi: 'ngôi nhà', telex: 'ngooi nhaf' },
    { vi: 'con chó', telex: 'con chos' },
    { vi: 'bông hoa', telex: 'boong hoa' },
    { vi: 'quả táo', telex: 'quar taso' },
    { vi: 'con gà', telex: 'con gaf' },
    { vi: 'cái bàn', telex: 'cais banf' },
    { vi: 'bầu trời', telex: 'baauf trowfi' },
    { vi: 'mặt trăng', telex: 'mawtj trawng' },
  ],
  // Tier 4: sentences — hardest, for stage bosses / late stages.
  sentences: [
    { vi: 'em yêu mẹ', telex: 'em yeeu mej' },
    { vi: 'trời nắng đẹp', telex: 'trowfi nawsng ddepj' },
    { vi: 'con cá bơi', telex: 'con cas bowi' },
    { vi: 'bé đi học', telex: 'bes ddi hocj' },
    { vi: 'chim hót vui', telex: 'chim hots vui' },
    { vi: 'mèo con dễ thương', telex: 'meof con deex thuwowng' },
    { vi: 'hoa nở mùa xuân', telex: 'hoa nowr muaf xuaan' },
  ],
};

// Pick a word from a pool by index (wraps).
export function pickWord(pool, index) {
  const list = WORD_POOLS[pool];
  return list[index % list.length];
}
