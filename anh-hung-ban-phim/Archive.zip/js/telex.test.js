// telex.test.js — run with: node js/telex.test.js
// Verifies the Telex engine against real Vietnamese words.

import { typeString } from './telex.js';

const cases = [
  // raw keystrokes  -> expected Vietnamese
  ['as', 'á'],
  ['af', 'à'],
  ['ar', 'ả'],
  ['ax', 'ã'],
  ['aj', 'ạ'],
  ['aa', 'â'],
  ['aw', 'ă'],
  ['ee', 'ê'],
  ['oo', 'ô'],
  ['ow', 'ơ'],
  ['uw', 'ư'],
  ['dd', 'đ'],
  ['ass', 'as'],       // undo tone
  ['aaa', 'aa'],       // undo shape
  ['ddd', 'dd'],       // undo đ
  // words
  ['me', 'me'],
  ['mej', 'mẹ'],       // mẹ
  ['boos', 'bố'],      // bố
  ['caf', 'cà'],       // cà
  ['gaf', 'gà'],       // gà
  ['meof', 'mèo'],     // mèo (tone on e)
  ['conf', 'còn'],     // còn (tone on o, final consonant)
  ['quar', 'quả'],     // quả (tone on a)
  ['cams', 'cám'],     // cám
  ['Vieejt', 'Việt'],  // Việt (ê priority + nang)
  ['dduwowcj', 'được'],// được
  ['nghieeng', 'nghiêng'], // nghiêng
  ['xin', 'xin'],
  ['chaof', 'chào'],   // chào
  ['hoas', 'hóa'],     // hóa (oa -> tone on a)
  ['thuys', 'thúy'],   // thúy (uy -> tone on y)
  // Multi-syllable: tone must stay within its own syllable (regression guard).
  ['quar taso', 'quả táo'],       // 's' on táo must NOT retone quả
  ['baauf trowfi', 'bầu trời'],
  ['mawtj trawng', 'mặt trăng'],
  ['bes ddi hocj', 'bé đi học'],
  ['meof con deex thuwowng', 'mèo con dễ thương'],
  ['hoa nowr muaf xuaan', 'hoa nở mùa xuân'],
];

let pass = 0;
let fail = 0;
for (const [raw, expected] of cases) {
  const got = typeString(raw);
  const ok = got === expected;
  if (ok) {
    pass++;
  } else {
    fail++;
    console.log(`FAIL  "${raw}"  expected "${expected}"  got "${got}"`);
  }
}
console.log(`\n${pass} passed, ${fail} failed, ${cases.length} total`);
process.exit(fail ? 1 : 0);
