// sprites.js — all game art as dot grids.
//
// Each sprite is an array of strings; every character is one "dot" cell:
//   ' ' (space) = transparent
//   any other char = filled, and the character is a palette key (see PALETTE).
// This lets a single sprite use multiple colors while staying human-editable.
//
// Palette keys are short so the grids line up visually in source.

export const PALETTE = {
  '#': '#2b2b2b', // dark (outline / classic Dino gray)
  '.': '#5a5a5a', // mid gray
  o: '#8a8a8a',   // light gray
  W: '#f4f4f4',   // white
  S: '#f2c9a0',   // skin
  H: '#7a4a1e',   // hair/brown
  B: '#3b6ea5',   // blue (armor/cloth)
  R: '#c0392b',   // red
  G: '#3aa655',   // green
  Y: '#e8c33a',   // yellow/gold
  P: '#c77dff',   // purple/magic
  C: '#4ad4d4',   // cyan
  M: '#8e44ad',   // dark magenta
};

// --- Hero: base skin "Knight" (facing right). 12 wide x 14 tall. ---
export const HERO_KNIGHT = {
  w: 12,
  h: 14,
  frames: [
    [
      '   ####     ',
      '  #YYYY#    ',
      '  #YWWY#    ',
      '  #WSSW#    ',
      '   #SS#     ',
      '  #BBBB#    ',
      ' #BBBBBB#   ',
      '#B#BBBB#o   ',
      '#B#BBBB#o   ',
      '  BB  BB    ',
      '  BB  BB    ',
      ' ##    ##   ',
      ' ##    ##   ',
      '            ',
    ],
    // walk frame 2 (legs swapped)
    [
      '   ####     ',
      '  #YYYY#    ',
      '  #YWWY#    ',
      '  #WSSW#    ',
      '   #SS#     ',
      '  #BBBB#    ',
      ' #BBBBBB#   ',
      '#B#BBBB#o   ',
      '#B#BBBB#o   ',
      '   BBBB     ',
      '  BB  BB    ',
      ' ##      ##  ',
      ' ##      ##  ',
      '            ',
    ],
  ],
};

// --- Hero skin "Mage" (reward from stage 2). Purple robe + hat. ---
export const HERO_MAGE = {
  w: 12,
  h: 14,
  frames: [
    [
      '   #PP#     ',
      '  #PPPP#    ',
      ' #PPPPPP#   ',
      '   #SS#     ',
      '   #SS#     ',
      '  #PPPP#    ',
      ' #PPPPPP#   ',
      '#P#PPPP#Y   ',
      '#P#PPPP#Y   ',
      '  PP  PP    ',
      '  PP  PP    ',
      ' ##    ##   ',
      ' ##    ##   ',
      '            ',
    ],
    [
      '   #PP#     ',
      '  #PPPP#    ',
      ' #PPPPPP#   ',
      '   #SS#     ',
      '   #SS#     ',
      '  #PPPP#    ',
      ' #PPPPPP#   ',
      '#P#PPPP#Y   ',
      '#P#PPPP#Y   ',
      '   PPPP     ',
      '  PP  PP    ',
      ' ##      ## ',
      ' ##      ## ',
      '            ',
    ],
  ],
};

// --- Princess (to be rescued). ---
export const PRINCESS = {
  w: 10,
  h: 14,
  frames: [
    [
      '  #YYYY#  ',
      ' #YWWWWY# ',
      '  #YYYY#  ',
      '  #SSSS#  ',
      '  HSSSSH  ',
      '   #SS#   ',
      '  #PPPP#  ',
      ' #PPPPPP# ',
      ' #PPPPPP# ',
      ' #PPPPPP# ',
      '#PPPPPPPP#',
      '#PPPPPPPP#',
      ' PP    PP ',
      ' ##    ## ',
    ],
  ],
};

// --- Creep monster: "Slime". 10 x 8 ---
export const CREEP_SLIME = {
  w: 10,
  h: 8,
  frames: [
    [
      '   ####   ',
      '  #GGGG#  ',
      ' #GGGGGG# ',
      '#GG#GG#GG#',
      '#GGGGGGGG#',
      '#G#GGGG#G#',
      '#GGGGGGGG#',
      ' ######## ',
    ],
    [
      '          ',
      '   ####   ',
      '  #GGGG#  ',
      ' #GG#GG#G#',
      '#GGGGGGGG#',
      '#G#GGGG#G#',
      '#GGGGGGGG#',
      ' ######## ',
    ],
  ],
};

// --- Boss monster: "Dragon". 16 x 14 ---
export const BOSS_DRAGON = {
  w: 16,
  h: 14,
  frames: [
    [
      '        ##      ',
      '   ##  #RR#     ',
      '  #RR##RRRR#    ',
      ' #RRRRRRRRR#    ',
      ' #RRRWWRRRRR#   ',
      '#RRRRWWRRRRRR#  ',
      '#RRRRRRRRRRRR#  ',
      ' #RRRRRRRRRR#   ',
      '  #RRRRRRRR#RR  ',
      '   #RRRRRR# RR  ',
      '  #RR#RR#RR#    ',
      '  RR  RR  RR    ',
      ' ##   ##   ##   ',
      '                ',
    ],
  ],
};

// --- Stage Boss: "Giant Ogre". 20 x 18 ---
export const STAGEBOSS_OGRE = {
  w: 20,
  h: 18,
  frames: [
    [
      '      ######        ',
      '    ##GGGGGG##      ',
      '   #GGGGGGGGGG#     ',
      '  #GGRRGGGGRRGG#    ',
      '  #GGWWGGGGWWGG#    ',
      '  #GGGGGGGGGGGG#    ',
      '  #GGG#YYYY#GGG#    ',
      '   #GGGGGGGGGG#     ',
      '  #GGGGGGGGGGGG#    ',
      ' #HHGGGGGGGGGGHH#   ',
      ' #HHGGGGGGGGGGHH#   ',
      ' #HH#GGGGGGGG#HH#   ',
      '    #GGGGGGGG#      ',
      '    GGGG  GGGG      ',
      '    GGGG  GGGG      ',
      '   ####    ####     ',
      '   ####    ####     ',
      '                    ',
    ],
  ],
};

export const SPRITES = {
  hero_knight: HERO_KNIGHT,
  hero_mage: HERO_MAGE,
  princess: PRINCESS,
  creep_slime: CREEP_SLIME,
  boss_dragon: BOSS_DRAGON,
  stageboss_ogre: STAGEBOSS_OGRE,
};
