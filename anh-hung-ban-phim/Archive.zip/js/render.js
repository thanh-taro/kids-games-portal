// render.js — dot-drawing primitives on a Canvas 2D context.
//
// Everything in the game is drawn as a grid of square "dots". A sprite's
// logical pixel is scaled up to DOT px on screen, giving the chunky retro look.

import { PALETTE } from './sprites.js';

export const DOT = 4; // on-screen size (px) of one sprite pixel at scale 1

// Draw a single sprite frame at (x, y) in screen pixels.
// scale multiplies DOT; flip=true mirrors horizontally (face left).
export function drawSprite(ctx, sprite, frameIdx, x, y, scale = 1, flip = false) {
  const frame = sprite.frames[frameIdx % sprite.frames.length];
  const px = DOT * scale;
  for (let row = 0; row < frame.length; row++) {
    const line = frame[row];
    for (let col = 0; col < line.length; col++) {
      const key = line[col];
      if (key === ' ') continue;
      const color = PALETTE[key] || '#2b2b2b';
      const cx = flip ? (sprite.w - 1 - col) : col;
      ctx.fillStyle = color;
      ctx.fillRect(x + cx * px, y + row * px, px, px);
    }
  }
}

// Draw a filled dot-rectangle (for HP bars, ground, UI panels).
export function drawRect(ctx, x, y, w, h, color) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

// Dotted ground line — a row of dashes like the Dino game.
export function drawGround(ctx, y, width, color = '#5a5a5a') {
  ctx.fillStyle = color;
  for (let x = 0; x < width; x += DOT * 2) {
    ctx.fillRect(x, y, DOT, DOT);
  }
}

// Retro bitmap-ish text using the canvas font (kept simple; the dot aesthetic
// comes from the pixel font set in CSS on the canvas context).
export function drawText(ctx, text, x, y, size = 16, color = '#f4f4f4', align = 'left') {
  ctx.fillStyle = color;
  ctx.textAlign = align;
  ctx.textBaseline = 'top';
  ctx.font = `${size}px "PixelFont", monospace`;
  ctx.fillText(text, x, y);
}

// Clear the whole canvas to a background color.
export function clear(ctx, w, h, color = '#f7f7f7') {
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, w, h);
}
