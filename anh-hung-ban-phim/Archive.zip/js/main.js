// main.js — Milestone 6: full game with state machine, stages, rewards.
//
// States: TITLE → STAGE_INTRO → PLAYING → (VICTORY → REWARD → next stage)
//                                        └→ FAILURE → retry stage
// Clearing the final stage → GAME_COMPLETE.

import { clear, drawSprite, drawGround, drawText, drawRect, DOT } from './render.js';
import { Hero, Monster, Projectile, MONSTER_KIND } from './entities.js';
import { ParticleSystem } from './effects.js';
import { TypingTracker, attachKeyboard } from './input.js';
import { SKILLS, SKILL_CLASS, pickWord } from './skills.js';
import { getStage, TOTAL_STAGES } from './stages.js';
import { rewardForStage, loadProgress, saveProgress, resetProgress, applyRewards } from './rewards.js';
import * as Scenes from './scenes.js';
import * as Audio from './audio.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;

const W = canvas.width;
const H = canvas.height;
const GROUND_Y = H - 60;

const STATE = {
  TITLE: 'title',
  STAGE_INTRO: 'stage_intro',
  PLAYING: 'playing',
  VICTORY: 'victory',
  REWARD: 'reward',
  FAILURE: 'failure',
  GAME_COMPLETE: 'game_complete',
};

// --- Persistent + session state ---
let progress = loadProgress();       // { stage, rewards: [] }
let state = STATE.TITLE;
let stageIndex = progress.stage;     // 0-based
let tick = 0;                        // global animation tick
let stateTick = 0;                   // resets each state change (for scene anims)

// --- Gameplay state (rebuilt per stage) ---
let hero, particles, tracker;
let monster = null;
let projectiles = [];
let waveCursor = 0;
let shakeTimer = 0;
let pendingReward = null;

tracker = new TypingTracker();
particles = new ParticleSystem();

function setState(next) {
  state = next;
  stateTick = 0;
}

// ---------------------------------------------------------------------------
// Stage lifecycle
// ---------------------------------------------------------------------------
function startStage() {
  const stage = getStage(stageIndex);
  hero = new Hero(120, GROUND_Y);
  applyRewards(hero, progress.rewards); // equip unlocked gear/skin
  monster = null;
  projectiles = [];
  waveCursor = 0;
  shakeTimer = 0;
  tracker.clear();
  setState(STATE.PLAYING);
}

function currentStage() {
  return getStage(stageIndex);
}

function spawnNextWave() {
  const stage = currentStage();
  if (waveCursor >= stage.waves.length) {
    // All waves cleared → victory.
    tracker.clear();
    Audio.victory();
    setState(STATE.VICTORY);
    return;
  }
  const wave = stage.waves[waveCursor];
  waveCursor++;

  const skill = SKILLS[wave.skill] || SKILLS.slash;

  if (wave.type === 'creep') {
    monster = new Monster(MONSTER_KIND.CREEP, 'creep_slime', W - 60, GROUND_Y, {
      speed: 0.32,
      hitsNeeded: 1,
    });
    monster.word = pickWord(wave.pool, waveCursor + stageIndex);
    monster.skill = skill;
  } else if (wave.type === 'elite') {
    monster = new Monster(MONSTER_KIND.CREEP, 'creep_slime', W - 60, GROUND_Y, {
      speed: 0.22,
      hitsNeeded: 1,
      contactDamage: 20,
    });
    monster.word = pickWord(wave.pool, waveCursor + stageIndex);
    monster.skill = skill;
    monster.tint = 'elite';
  } else if (wave.type === 'boss') {
    monster = new Monster(MONSTER_KIND.BOSS, 'boss_dragon', W - 40, GROUND_Y, {
      speed: 0.6,
      hitsNeeded: 3,
      standGap: 330,
      attackEvery: 210,
      attackDamage: 12,
    });
    monster.skill = skill;
    monster.displayName = 'Rồng Lửa';
    monster.pool = wave.pool;
    assignBossWord();
  } else if (wave.type === 'stageboss') {
    monster = new Monster(MONSTER_KIND.STAGEBOSS, 'stageboss_ogre', W - 30, GROUND_Y, {
      speed: 0.5,
      hitsNeeded: 6,
      standGap: 360,
      attackEvery: 180,
      attackDamage: 15,
    });
    monster.skill = skill;
    monster.displayName = currentStage().princess ? 'Quỷ Khổng Lồ' : 'Quỷ';
    monster.pool = wave.pool;
    assignBossWord();
  }
  if (monster.word) tracker.setTarget(monster.word.vi);
}

function assignBossWord() {
  const pool = monster.pool || (monster.kind === MONSTER_KIND.STAGEBOSS ? 'sentences' : 'phrases');
  const idx = monster.maxHits - monster.hitsLeft + waveCursor + stageIndex;
  monster.word = pickWord(pool, idx);
  tracker.setTarget(monster.word.vi);
}

// ---------------------------------------------------------------------------
// Combat callbacks
// ---------------------------------------------------------------------------
// Per-keystroke audio feedback: a rising blip on progress, a buzz on mistake.
tracker.onProgress = (matchedLen, mistake) => {
  if (mistake) Audio.keyError();
  else Audio.keyBlip(matchedLen);
};

tracker.onComplete = () => {
  if (!monster || monster.dying) return;
  const skill = monster.skill;
  Audio.keyBlip(monster.word ? monster.word.vi.length : 4);
  if (skill.cls === SKILL_CLASS.SPECIAL) Audio.specialAttack();
  else Audio.simpleAttack();
  hero.triggerAttack();

  const startX = hero.x + hero.sprite.w * DOT * hero.scale;
  const startY = hero.y + (hero.sprite.h * DOT * hero.scale) / 2;
  const targetX = monster.x + monster.width / 2;

  const pj = skill.projectile;
  const color = hero.weaponColor && skill.cls === SKILL_CLASS.SIMPLE ? hero.weaponColor : pj.color;
  const speed = pj.speed + (hero.projectileSpeedBonus || 0);
  tracker.clear();
  for (let i = 0; i < pj.count; i++) {
    const offset = (i - (pj.count - 1) / 2) * 10;
    const proj = new Projectile(startX, startY + offset, targetX, {
      speed,
      color,
      size: pj.size,
      special: pj.special,
    });
    proj.isLeadHit = i === 0;
    projectiles.push(proj);
  }
  if (skill.shake) shakeTimer = skill.shake;
};

function onProjectileHit(p) {
  if (!monster) return;
  const skill = monster.skill;
  const cx = monster.x + monster.width / 2;
  const cy = monster.y + (monster.sprite.h * DOT * monster.scale) / 2;
  const b = skill.burst;
  particles.burst(cx, cy, b.color, b.n, b.power);

  if (!p.isLeadHit || monster.dying) return;
  Audio.hit();
  monster.registerHit();
  if (!monster.isDefeated) {
    assignBossWord(); // boss survives → next word
  }
}

function heroHit(dmg) {
  hero.takeDamage(dmg);
  shakeTimer = Math.max(shakeTimer, 12);
  particles.burst(hero.x + 30, hero.y + 30, '#c0392b', 12, 4);
  Audio.hurt();
  if (hero.isDead) {
    tracker.clear();
    Audio.failure();
    setState(STATE.FAILURE);
  }
}

// ---------------------------------------------------------------------------
// Update
// ---------------------------------------------------------------------------
function updatePlaying() {
  hero.update();

  if (!monster) {
    spawnNextWave();
    if (state !== STATE.PLAYING) return; // victory triggered
  }

  if (monster) {
    monster.update(hero.x);

    if (monster.reachedHero(hero.x) && !monster.dying) {
      heroHit(monster.contactDamage);
      if (state !== STATE.PLAYING) return;
      monster.dying = true;
      monster.deathTimer = 0;
      tracker.clear();
    }
    const bossDmg = monster.takeAttack();
    if (bossDmg > 0) {
      heroHit(bossDmg);
      if (state !== STATE.PLAYING) return;
    }

    if (monster.isGone) {
      monster = null;
      tracker.clear();
    }
  }

  for (const p of projectiles) {
    p.update();
    if (p.done) onProjectileHit(p);
  }
  projectiles = projectiles.filter((p) => !p.done);

  particles.update();
  if (shakeTimer > 0) shakeTimer--;
}

// Award the stage's reward and advance progress.
function grantReward() {
  pendingReward = rewardForStage(stageIndex);
  if (!progress.rewards.includes(pendingReward.id)) {
    progress.rewards.push(pendingReward.id);
  }
  progress.stage = Math.min(stageIndex + 1, TOTAL_STAGES - 1);
  saveProgress(progress);
}

// ---------------------------------------------------------------------------
// Input for scene transitions (SPACE advances; R resets)
// ---------------------------------------------------------------------------
window.addEventListener('keydown', (e) => {
  // First user gesture unlocks the AudioContext (browsers require this).
  Audio.resumeAudio();

  // M toggles mute at any time.
  if (e.key === 'm' || e.key === 'M') {
    Audio.toggleMute();
    return;
  }
  if (e.key === 'r' || e.key === 'R') {
    if (state === STATE.TITLE) {
      resetProgress();
      progress = { stage: 0, rewards: [] };
      stageIndex = 0;
      Audio.confirm();
    }
  }
  if (e.code !== 'Space') return;
  // During PLAYING, SPACE is a normal typing character (phrases have spaces) —
  // let the typing tracker handle it; don't treat it as a menu confirm.
  if (state === STATE.PLAYING) return;
  e.preventDefault();
  Audio.confirm();

  if (state === STATE.TITLE) {
    stageIndex = progress.stage;
    setState(STATE.STAGE_INTRO);
  } else if (state === STATE.STAGE_INTRO) {
    startStage();
  } else if (state === STATE.VICTORY) {
    grantReward();
    Audio.reward();
    setState(STATE.REWARD);
  } else if (state === STATE.REWARD) {
    if (stageIndex + 1 >= TOTAL_STAGES) {
      setState(STATE.GAME_COMPLETE);
    } else {
      stageIndex += 1;
      setState(STATE.STAGE_INTRO);
    }
  } else if (state === STATE.FAILURE) {
    startStage(); // retry same stage
  } else if (state === STATE.GAME_COMPLETE) {
    resetProgress();
    progress = { stage: 0, rewards: [] };
    stageIndex = 0;
    setState(STATE.TITLE);
  }
});

// Gameplay typing keys are handled by the tracker (only active while PLAYING).
attachKeyboard(tracker);

// ---------------------------------------------------------------------------
// Render helpers (gameplay HUD + entities)
// ---------------------------------------------------------------------------
function drawTargetWord() {
  if (!monster || monster.dying || !monster.word) return;
  const cx = Math.min(Math.max(monster.x + monster.width / 2, 110), W - 110);
  const topY = monster.y - 58;
  const word = monster.word;
  const matched = tracker.matchedLen();
  const mistake = tracker.isMistake();
  const isSpecial = monster.skill.cls === SKILL_CLASS.SPECIAL;

  const size = 26;
  ctx.font = `${size}px "PixelFont", monospace`;
  const textW = ctx.measureText(word.vi).width;
  const bg = isSpecial ? '#3a1a1a' : '#2b2b2b';
  drawRect(ctx, cx - textW / 2 - 14, topY - 10, textW + 28, size + 20, bg);
  if (isSpecial) drawRect(ctx, cx - textW / 2 - 14, topY - 10, textW + 28, 3, '#c0392b');

  ctx.textAlign = 'left';
  ctx.textBaseline = 'top';
  let dx = cx - textW / 2;
  for (let i = 0; i < word.vi.length; i++) {
    let color = '#f4f4f4';
    if (i < matched) color = '#3aa655';
    else if (mistake && i === matched) color = '#c0392b';
    ctx.fillStyle = color;
    ctx.fillText(word.vi[i], dx, topY);
    dx += ctx.measureText(word.vi[i]).width;
  }

  const label = isSpecial ? `⚡ ${monster.skill.name}` : monster.skill.name;
  drawText(ctx, label, cx, topY - 26, 12, isSpecial ? '#e8622b' : '#8a8a8a', 'center');
  drawText(ctx, `(${word.telex})`, cx, topY + size + 6, 12, '#8a8a8a', 'center');
}

function drawBossBar() {
  if (!monster || monster.kind === MONSTER_KIND.CREEP) return;
  const cx = Math.min(Math.max(monster.x + monster.width / 2, 130), W - 130);
  const barW = 200;
  const barH = 12;
  const barX = cx - barW / 2;
  const barY = monster.y - 118;

  drawText(ctx, monster.displayName, cx, barY - 22, 15, '#2b2b2b', 'center');
  drawRect(ctx, barX - 2, barY - 2, barW + 4, barH + 4, '#2b2b2b');
  const frac = monster.hitsLeft / monster.maxHits;
  drawRect(ctx, barX, barY, barW, barH, '#5a5a5a');
  drawRect(ctx, barX, barY, barW * frac, barH, '#c0392b');
  drawText(ctx, `${monster.hitsLeft}/${monster.maxHits}`, barX + barW + 8, barY - 1, 12, '#5a5a5a', 'left');
}

function drawHUD() {
  const stage = currentStage();
  const barW = 220;
  const barH = 18;
  drawRect(ctx, 20, 20, barW, barH, '#2b2b2b');
  const hpW = (hero.hp / hero.maxHp) * (barW - 4);
  drawRect(ctx, 22, 22, hpW, barH - 4, hero.hp > 30 ? '#3aa655' : '#c0392b');
  drawText(ctx, `HP ${hero.hp}`, 24, 21, 12, '#f4f4f4', 'left');

  drawText(ctx, `Màn ${stage.id}: ${stage.name}`, W / 2, 22, 14, '#2b2b2b', 'center');
  const total = stage.waves.length;
  drawText(ctx, `Đợt ${Math.min(waveCursor, total)}/${total}`, W - 20, 20, 14, '#2b2b2b', 'right');
}

function renderPlaying() {
  const ox = shakeTimer > 0 ? (tick % 2 === 0 ? 4 : -4) : 0;
  ctx.save();
  ctx.translate(ox, 0);

  clear(ctx, W, H, '#f7f7f7');
  drawGround(ctx, GROUND_Y, W);

  const lunge = hero.attackAnim > 0 ? 10 : 0;
  drawSprite(ctx, hero.sprite, hero.frame, hero.x + lunge, hero.y, hero.scale);

  if (monster) {
    if (!monster.dying || monster.deathTimer % 4 < 2) {
      drawSprite(ctx, monster.sprite, monster.frame, monster.x, monster.y, monster.scale, true);
      if (monster.tint === 'elite' && !monster.dying) {
        drawRect(ctx, monster.x + monster.width / 2 - 4, monster.y - 6, 8, 6, '#c0392b');
      }
    }
  }

  for (const p of projectiles) {
    for (let i = 0; i < p.trail.length; i++) {
      ctx.globalAlpha = i / p.trail.length;
      drawRect(ctx, p.trail[i].x, p.trail[i].y, p.size, p.size, p.color);
    }
    ctx.globalAlpha = 1;
    drawRect(ctx, p.x, p.y, p.size, p.size, p.color);
  }

  particles.draw(ctx);
  drawBossBar();
  drawTargetWord();
  drawHUD();
  drawText(ctx, 'Gõ chữ để tấn công! (Telex)', W / 2, H - 34, 14, '#5a5a5a', 'center');
  drawText(ctx, Audio.isMuted() ? '🔇 M: bật tiếng' : '🔊 M: tắt tiếng', W - 20, H - 34, 11, '#8a8a8a', 'right');

  ctx.restore();
}

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
function loop() {
  tick++;
  stateTick++;

  switch (state) {
    case STATE.TITLE:
      Scenes.drawTitle(ctx, W, H, tick);
      break;
    case STATE.STAGE_INTRO:
      Scenes.drawStageIntro(ctx, W, H, tick, currentStage());
      break;
    case STATE.PLAYING:
      updatePlaying();
      // updatePlaying may have transitioned state; guard the render.
      if (state === STATE.PLAYING) renderPlaying();
      else if (state === STATE.VICTORY) Scenes.drawVictory(ctx, W, H, tick, currentStage());
      else if (state === STATE.FAILURE) Scenes.drawFailure(ctx, W, H, tick, currentStage());
      break;
    case STATE.VICTORY:
      Scenes.drawVictory(ctx, W, H, tick, currentStage());
      break;
    case STATE.REWARD:
      Scenes.drawReward(ctx, W, H, tick, pendingReward);
      break;
    case STATE.FAILURE:
      Scenes.drawFailure(ctx, W, H, tick, currentStage());
      break;
    case STATE.GAME_COMPLETE:
      Scenes.drawGameComplete(ctx, W, H, tick);
      break;
  }

  requestAnimationFrame(loop);
}

loop();
