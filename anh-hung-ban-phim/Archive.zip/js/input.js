// input.js — captures raw keystrokes, runs them through the Telex engine, and
// tracks progress against a target Vietnamese word.
//
// The game sets a target (e.g. "mèo"). The kid types raw Telex keys ("meof").
// After each key we render the buffer and compare, prefix-wise, to the target:
//   - matchedLen: how many leading chars of the target are correct so far
//   - complete: whole target matched
//   - mistake: the current buffer diverges from the target (wrong path)

import { newBuffer, applyKey, render } from './telex.js';

export class TypingTracker {
  constructor() {
    this.buffer = newBuffer();
    this.target = '';
    this.onComplete = null; // callback set by game
    this.onProgress = null; // callback(matchedLen, mistake)
    this.enabled = false;
  }

  setTarget(word) {
    this.target = word;
    this.buffer = newBuffer();
    this.enabled = true;
  }

  clear() {
    this.buffer = newBuffer();
    this.enabled = false;
  }

  get current() {
    return render(this.buffer);
  }

  // How many leading characters currently match the target.
  matchedLen() {
    const cur = this.current;
    let i = 0;
    while (i < cur.length && i < this.target.length && cur[i] === this.target[i]) i++;
    return i;
  }

  // True if the current buffer has gone "off the rails" (diverged from target).
  isMistake() {
    const cur = this.current;
    // A mistake = current string is not a prefix of the target.
    return !this.target.startsWith(cur);
  }

  handleKey(key) {
    if (!this.enabled) return;

    if (key === 'Backspace') {
      // Drop the last atom (approximate character-level undo).
      this.buffer = this.buffer.slice(0, -1);
      this._emitProgress();
      return;
    }
    // Only accept single printable characters.
    if (key.length !== 1) return;

    this.buffer = applyKey(this.buffer, key);
    const cur = this.current;

    if (cur === this.target) {
      this.enabled = false;
      if (this.onProgress) this.onProgress(this.target.length, false);
      if (this.onComplete) this.onComplete();
      return;
    }
    this._emitProgress();
  }

  _emitProgress() {
    if (this.onProgress) this.onProgress(this.matchedLen(), this.isMistake());
  }
}

// Install a global keydown listener that forwards keys to a tracker.
// Returns a teardown function.
export function attachKeyboard(tracker) {
  const handler = (e) => {
    // Ignore modifier combos so shortcuts still work.
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === 'Backspace') {
      e.preventDefault();
      tracker.handleKey('Backspace');
      return;
    }
    if (e.key.length === 1) {
      e.preventDefault();
      tracker.handleKey(e.key);
    }
  };
  window.addEventListener('keydown', handler);
  return () => window.removeEventListener('keydown', handler);
}
