// scenes.js — non-gameplay screens drawn on the canvas.
//
// Each function draws one full-screen scene. main.js decides which to call
// based on the current game state, and passes the data each needs.

import { clear, drawSprite, drawGround, drawText, drawRect, DOT } from './render.js';
import { SPRITES } from './sprites.js';

// Simple animated dot-starfield background helper used by a few scenes.
function drawSparkles(ctx, W, H, tick, color = '#c77dff') {
  for (let i = 0; i < 24; i++) {
    const x = (i * 137 + tick * (1 + (i % 3))) % W;
    const y = (i * 53) % (H - 120) + 20;
    const on = (tick + i * 7) % 40 < 20;
    if (on) {
      ctx.fillStyle = color;
      ctx.fillRect(x, y, DOT, DOT);
    }
  }
}

export function drawTitle(ctx, W, H, tick) {
  clear(ctx, W, H, '#0f1020');
  drawSparkles(ctx, W, H, tick, '#4ad4d4');

  drawText(ctx, 'CỨU CÔNG CHÚA', W / 2, 90, 44, '#f4f4f4', 'center');
  drawText(ctx, 'Học gõ Tiếng Việt — Telex', W / 2, 142, 18, '#c77dff', 'center');

  // Hero + princess standing lower, clear of the title.
  const gy = H - 130;
  drawSprite(ctx, SPRITES.hero_knight, Math.floor(tick / 10) % 2, W / 2 - 150, gy - SPRITES.hero_knight.h * DOT * 3, 3);
  drawSprite(ctx, SPRITES.princess, 0, W / 2 + 90, gy - SPRITES.princess.h * DOT * 3, 3);

  // Blinking "press to start".
  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để bắt đầu', W / 2, H - 90, 20, '#e8c33a', 'center');
  }
  drawText(ctx, 'Nhấn R để chơi lại từ đầu', W / 2, H - 50, 12, '#5a5a5a', 'center');
}

export function drawStageIntro(ctx, W, H, tick, stage) {
  clear(ctx, W, H, '#0f1020');
  drawSparkles(ctx, W, H, tick, '#3aa655');

  drawText(ctx, `MÀN ${stage.id}`, W / 2, H / 2 - 100, 28, '#8a8a8a', 'center');
  drawText(ctx, stage.name, W / 2, H / 2 - 56, 40, '#f4f4f4', 'center');
  drawText(ctx, stage.intro, W / 2, H / 2 + 4, 20, '#4ad4d4', 'center');
  drawText(ctx, `Giải cứu ${stage.princess}`, W / 2, H / 2 + 44, 16, '#c77dff', 'center');

  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để vào trận', W / 2, H - 80, 18, '#e8c33a', 'center');
  }
}

export function drawVictory(ctx, W, H, tick, stage) {
  clear(ctx, W, H, '#101a10');
  drawSparkles(ctx, W, H, tick, '#e8c33a');

  drawText(ctx, 'CHIẾN THẮNG!', W / 2, 70, 44, '#e8c33a', 'center');
  drawText(ctx, `Đã giải cứu ${stage.princess}!`, W / 2, 130, 20, '#f4f4f4', 'center');

  // Hero and rescued princess celebrating on the ground, close together.
  const gy = H - 140;
  const bob = Math.floor(tick / 8) % 2 === 0 ? 0 : -6;
  drawSprite(ctx, SPRITES.hero_knight, Math.floor(tick / 10) % 2, W / 2 - 120, gy - SPRITES.hero_knight.h * DOT * 4, 4);
  drawSprite(ctx, SPRITES.princess, 0, W / 2 + 20, gy - SPRITES.princess.h * DOT * 4 + bob, 4);

  // Rising heart-dots between them.
  for (let i = 0; i < 5; i++) {
    const hy = gy - 40 - ((tick * 2 + i * 30) % 160);
    const hx = W / 2 - 10 + Math.sin((tick + i * 20) / 20) * 20;
    ctx.fillStyle = '#c0392b';
    ctx.fillRect(hx, hy, DOT * 2, DOT * 2);
  }

  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để nhận thưởng', W / 2, H - 50, 18, '#e8c33a', 'center');
  }
}

export function drawReward(ctx, W, H, tick, reward) {
  clear(ctx, W, H, '#0f1020');
  drawSparkles(ctx, W, H, tick, '#e8c33a');

  const typeLabel =
    reward.type === 'weapon' ? 'VŨ KHÍ MỚI' : reward.type === 'skin' ? 'TRANG PHỤC MỚI' : 'KỸ NĂNG MỚI';
  drawText(ctx, '★ PHẦN THƯỞNG ★', W / 2, 80, 24, '#8a8a8a', 'center');
  drawText(ctx, typeLabel, W / 2, 120, 18, '#c77dff', 'center');

  // A pulsing "card" showing the reward name.
  const pulse = 1 + Math.sin(tick / 10) * 0.03;
  const cardW = 360 * pulse;
  const cardH = 120;
  const cx = W / 2;
  const cy = H / 2 + 10;
  drawRect(ctx, cx - cardW / 2, cy - cardH / 2, cardW, cardH, '#2b2b2b');
  drawRect(ctx, cx - cardW / 2, cy - cardH / 2, cardW, 4, '#e8c33a');

  // Reward icon: a big dot in its theme color.
  const iconColor = reward.projectileColor || '#e8c33a';
  drawRect(ctx, cx - 12, cy - 44, 24, 24, iconColor);

  drawText(ctx, reward.name, cx, cy - 4, 26, '#f4f4f4', 'center');
  drawText(ctx, reward.desc, cx, cy + 30, 15, '#8a8a8a', 'center');

  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để tiếp tục', W / 2, H - 60, 18, '#e8c33a', 'center');
  }
}

export function drawFailure(ctx, W, H, tick, stage) {
  clear(ctx, W, H, '#1a1010');
  drawText(ctx, 'THẤT BẠI...', W / 2, H / 2 - 80, 44, '#c0392b', 'center');
  drawText(ctx, 'Anh hùng đã ngã xuống.', W / 2, H / 2 - 20, 18, '#f4f4f4', 'center');
  drawText(ctx, 'Đừng bỏ cuộc — hãy thử lại!', W / 2, H / 2 + 14, 16, '#8a8a8a', 'center');

  // Fallen hero (drawn upside-ish by shifting).
  const gy = H / 2 + 120;
  drawSprite(ctx, SPRITES.hero_knight, 0, W / 2 - 24, gy, 3);

  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để thử lại màn này', W / 2, H - 70, 18, '#e8c33a', 'center');
  }
}

export function drawGameComplete(ctx, W, H, tick) {
  clear(ctx, W, H, '#0f1020');
  drawSparkles(ctx, W, H, tick, '#e8c33a');
  drawSparkles(ctx, W, H, tick + 20, '#4ad4d4');

  drawText(ctx, 'HOÀN THÀNH!', W / 2, H / 2 - 80, 48, '#e8c33a', 'center');
  drawText(ctx, 'Bạn đã cứu tất cả công chúa!', W / 2, H / 2 - 20, 20, '#f4f4f4', 'center');
  drawText(ctx, 'Bạn gõ Tiếng Việt rất giỏi! 🎉', W / 2, H / 2 + 20, 18, '#c77dff', 'center');

  if (tick % 60 < 40) {
    drawText(ctx, '▶ Nhấn SPACE để chơi lại', W / 2, H - 70, 18, '#e8c33a', 'center');
  }
}
